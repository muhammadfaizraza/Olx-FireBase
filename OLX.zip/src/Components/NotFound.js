import React from "react";
import "../Styles/Notfound.css"
const NotFound = () => {
  return (
    <div className="notFound">
      <p>N</p>
      <p>O</p>
      <p>T</p>
      <p>F</p>
      <p>O</p>
      <p>U</p>
      <p>N</p>
      <p>D</p>
      
    </div>
  );
};

export default NotFound;
